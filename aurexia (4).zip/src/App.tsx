/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, FormEvent } from "react";
import { INITIAL_CREATORS, INITIAL_BRANDS, INITIAL_CAMPAIGNS, INITIAL_ACTIVITIES } from "./data";
import { Creator, CampaignOpportunity, LiveActivity } from "./types";
import { motion, AnimatePresence } from "motion/react";

// Import modular subcomponents
import AIAgentNetwork from "./components/AIAgentNetwork";
import TrustIntelligence from "./components/TrustIntelligence";
import BrandDashboardView from "./components/BrandDashboardView";
import CreatorDashboardView from "./components/CreatorDashboardView";
import CampaignHubView from "./components/CampaignHubView";
import AnalyticsView from "./components/AnalyticsView";
import MessagingCenterView from "./components/MessagingCenterView";
import OnboardingHelper from "./components/OnboardingHelper";
import LoginGateway from "./components/LoginGateway";
import ComparatorView from "./components/ComparatorView";

// Lux icons
import {
  Sparkles,
  ShieldAlert,
  Building,
  User,
  Activity,
  ArrowRight,
  TrendingUp,
  Cpu,
  Key,
  Database,
  Briefcase,
  HelpCircle,
  Award,
  CheckCircle2,
  RefreshCw,
  Eye,
  Settings,
  AlertTriangle,
  Bot,
  Facebook,
  Instagram,
  Twitter,
  Phone,
  Mail,
  MapPin,
  Layers,
  Lock,
  ShieldCheck,
  Bell,
  Menu,
  X
} from "lucide-react";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeScreen, setActiveScreen] = useState<"landing" | "dashboard" | "login">("landing");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const [currentUser, setCurrentUser] = useState<{
    type: "brand" | "creator";
    id: string;
    name: string;
    avatar: string;
    handle?: string;
    details?: string;
    trustScore?: number;
  } | null>(null);
  
  // Dashboard primary tab router
  const [dashboardTab, setDashboardTab] = useState<
    "ai_network" | "trust_ledger" | "brand_hub" | "creator_hub" | "campaign" | "analytics" | "messaging" | "onboarding" | "comparison"
  >("brand_hub");

  // Selected role for dynamic homepage preview widgets
  const [homepageRole, setHomepageRole] = useState<"brand" | "creator">("brand");
  
  // Live Activity Center and persistent Notification states
  const [activities, setActivities] = useState<LiveActivity[]>(INITIAL_ACTIVITIES);
  const [notifications, setNotifications] = useState<LiveActivity[]>(INITIAL_ACTIVITIES);
  const [showNotifications, setShowNotifications] = useState(false);
  const [hasNewNotifications, setHasNewNotifications] = useState(true);

  // Match Maker interactive demo state (BRAND VIEW)
  const [inputBrandName, setInputBrandName] = useState("Nike India");
  const [inputProductName, setInputProductName] = useState("Air Max Infinity");
  const [inputBudget, setInputBudget] = useState("₹20,00,000");
  const [inputAudience, setInputAudience] = useState("Sustainable Lifestyle");
  const [isMatchingRunning, setIsMatchingRunning] = useState(false);
  const [matchedResults, setMatchedResults] = useState<Creator[]>([INITIAL_CREATORS[0], INITIAL_CREATORS[1]]);

  // Match Maker state (CREATOR VIEW)
  const [appliedCampaignId, setAppliedCampaignId] = useState<string[]>([]);
  const [bookmarkedCampaignId, setBookmarkedCampaignId] = useState<string[]>([]);

  // Navigation callbacks
  const [chatCreatorId, setChatCreatorId] = useState<string>("creator_1");
  const [selectedCreatorProfile, setSelectedCreatorProfile] = useState<Creator>(INITIAL_CREATORS[0]);

  // AI Copilot Everywhere active recommendations list
  const [aiCopilotOpened, setAiCopilotOpened] = useState(true);

  // Triggering new simulated activity events to make the platform feel ALIVE
  useEffect(() => {
    const alertsPool = [
      "🛡️ Audience analysis complete for Marcus Chen: no bot spikes found.",
      "🧠 AI matching parsed 15 high-contrast fashion profiles for Zara Autumn brief.",
      "⛓️ reputation record locked: Rajesh Sharma fulfilled Premium Foods delivery.",
      "📈 predicted campaign ROI for L'Oreal cosmetics updated to solid 7.4x yield.",
      "🤝 Sarah Kapoor submitted Reel draft. Deliverables tracking oracle standing is ready.",
    ];

    const interval = setInterval(() => {
      const selectedAlert = alertsPool[Math.floor(Math.random() * alertsPool.length)];
      
      const newAct: LiveActivity = {
        id: "act_" + Date.now(),
        text: selectedAlert,
        type: "ai_match",
        timestamp: "Just now"
      };
      
      setNotifications(prev => [newAct, ...prev]);
      setActivities(prev => [newAct, ...prev.slice(0, 4)]);
      setHasNewNotifications(true);
    }, 12000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3200);
    return () => clearTimeout(timer);
  }, []);

  const handleRunMatchMaker = (e: FormEvent) => {
    e.preventDefault();
    setIsMatchingRunning(true);
    setTimeout(() => {
      // Return custom match orders
      setMatchedResults([INITIAL_CREATORS[0], INITIAL_CREATORS[1], INITIAL_CREATORS[2]]);
      setIsMatchingRunning(false);
    }, 1200);
  };

  const handleApplyCampaign = (id: string) => {
    setAppliedCampaignId(prev => [...prev, id]);
  };

  const handleBookmarkCampaign = (id: string) => {
    setBookmarkedCampaignId(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen flex flex-col bg-warm-ivory text-charcoal selection:bg-gold selection:text-[#B5935B] font-sans border-[inset] border-[3px]">
      
      {/* Luxury Intro Splash Screen */}
      <AnimatePresence>
        {showSplash && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
            className="fixed inset-0 bg-[#0e2213] z-[9999] flex flex-col items-center justify-center text-center overflow-hidden"
            style={{ backgroundColor: "#0c2414" }}
          >
            {/* Ambient gold glow centered behind the logo */}
            <div className="absolute inset-x-0 top-1/4 bottom-1/4 bg-[radial-gradient(circle_at_center,rgba(212,150,35,0.12)_0%,rgba(12,36,20,0)_60%)] pointer-events-none" />
            
            <div className="relative z-10 flex flex-col items-center justify-center">
              {/* Logo Composition Group */}
              <div className="relative flex flex-col items-center select-none pointer-events-none">
                
                {/* 1. The Sculptural Golden 'A' Emblem coming up first */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.65, y: 70 }}
                  animate={{ 
                    opacity: 1, 
                    scale: 1, 
                    y: 0,
                  }}
                  transition={{ 
                    duration: 1.3, 
                    ease: [0.16, 1, 0.3, 1] 
                  }}
                  className="relative z-20 flex items-center justify-center drop-shadow-[0_15px_30px_rgba(212,150,35,0.25)] mb-6 w-32 h-32 md:w-36 md:h-36"
                >
                  <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-[0_10px_20px_rgba(0,0,0,0.5)]">
                    <defs>
                      <linearGradient id="goldGradBig" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#FFF1D0" />
                        <stop offset="40%" stopColor="#D4AF37" />
                        <stop offset="70%" stopColor="#AA7C11" />
                        <stop offset="100%" stopColor="#F3E5AB" />
                      </linearGradient>
                      <linearGradient id="darkBgBig" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#1B2A1E" />
                        <stop offset="100%" stopColor="#0B130E" />
                      </linearGradient>
                    </defs>
                    <rect x="2" y="2" width="96" height="96" rx="20" fill="url(#darkBgBig)" stroke="url(#goldGradBig)" strokeWidth="3" />
                    <circle cx="50" cy="50" r="38" stroke="url(#goldGradBig)" strokeWidth="1" strokeDasharray="3 2" opacity="0.6" />
                    <circle cx="50" cy="50" r="35" stroke="url(#goldGradBig)" strokeWidth="0.75" opacity="0.4" />
                    <path 
                      d="M50 25 C57 25, 66 33, 60 43 C54 53, 46 47, 40 57 C34 67, 43 75, 50 75 C57 75, 66 67, 60 57 C54 47, 46 53, 40 43 C34 33, 43 25, 50 25 Z" 
                      stroke="url(#goldGradBig)" 
                      strokeWidth="5" 
                      fill="none" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                    />
                    <circle cx="50" cy="50" r="16" stroke="url(#goldGradBig)" strokeWidth="1.5" strokeDasharray="4 2" fill="none" opacity="0.8" />
                    <circle cx="50" cy="50" r="8" fill="url(#goldGradBig)" opacity="0.9" />
                  </svg>
                </motion.div>

                {/* 2. The brand name "AUREXIA" coming from behind (the back of) that 'A' Emblem */}
                <div className="relative h-14 overflow-visible flex items-center justify-center">
                  <motion.h1
                    initial={{ opacity: 0, y: -50, scale: 0.8 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ 
                      delay: 0.9, 
                      duration: 1.1, 
                      ease: [0.16, 1, 0.3, 1] 
                    }}
                    className="font-serif text-4xl md:text-5xl tracking-[0.25em] font-extrabold text-[#f7eeee] drop-shadow-lg"
                    style={{ textShadow: "0 4px 18px rgba(0,0,0,0.5)" }}
                  >
                    AUREXIA
                  </motion.h1>
                </div>
                
              </div>

              {/* 3. Followed by "CREATOR & BRAND COLLABORATIONS" written at the bottom */}
              <div className="h-8 flex items-center justify-center mt-6 overflow-hidden">
                <motion.span
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 0.85, y: 0 }}
                  transition={{ 
                    delay: 1.8, 
                    duration: 0.9, 
                    ease: "easeOut" 
                  }}
                  className="text-[10px] md:text-xs font-mono font-bold tracking-[0.38em] text-[#E5B25D] block"
                >
                  CREATOR & BRAND COLLABORATIONS
                </motion.span>
              </div>

              {/* Luxury loading sequence line at bottom */}
              <div className="w-48 h-[1px] bg-white/10 rounded-full mt-10 overflow-hidden">
                <motion.div 
                  initial={{ width: "0%" }}
                  animate={{ width: "100%" }}
                  transition={{ duration: 2.4, ease: "easeInOut" }}
                  className="h-full bg-gradient-to-r from-transparent via-[#E5B25D] to-transparent"
                />
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Luxury Corporate Header */}
      <header className="border-b border-soft-warm-gray sticky top-0 bg-[#1c3e24] backdrop-blur-md z-50 px-6 py-3 flex justify-between items-center w-full" style={{ backgroundColor: "#1c3e24", height: "80px", width: "100%", maxWidth: "1539.4px" }}>
        <div 
          className="flex items-center gap-2 bg-transparent select-none cursor-pointer transition-transform hover:scale-[1.03]" 
          onClick={() => setActiveScreen("landing")}
          title="Return to homepage"
        >
          <div className="object-cover rounded-lg border border-[#dacfc2]/20 shadow-lg bg-[#142F1B] p-1 shadow-inner" style={{ width: "92px", height: "69px" }}>
            <svg viewBox="0 0 120 90" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
              <defs>
                <linearGradient id="headerGold" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#FFF2D4" />
                  <stop offset="50%" stopColor="#D4AF37" />
                  <stop offset="100%" stopColor="#A37E2C" />
                </linearGradient>
              </defs>
              <circle cx="60" cy="28" r="20" fill="#142F1B" stroke="url(#headerGold)" strokeWidth="1.5" />
              <circle cx="60" cy="28" r="17" stroke="url(#headerGold)" strokeWidth="0.5" strokeDasharray="2 1" opacity="0.6" />
              <path 
                d="M60 15.5 C63.5 15.5, 68 19.5, 65 24.5 C62 29.5, 58 26.5, 55 31.5 C52 36.5, 56.5 40.5, 60 40.5 C63.5 40.5, 68 36.5, 65 31.5 C62 26.5, 58 29.5, 55 24.5 C52 19.5, 56.5 15.5, 60 15.5 Z" 
                stroke="url(#headerGold)" 
                strokeWidth="2" 
                fill="none" 
                strokeLinecap="round" 
                strokeLinejoin="round" 
              />
              <circle cx="60" cy="28" r="3.5" fill="url(#headerGold)" />
              <text x="60" y="62" fill="url(#headerGold)" fontSize="12.5" fontWeight="900" fontFamily="Playfair Display, serif, Inter" letterSpacing="0.25em" textAnchor="middle">AUREXIA</text>
              <text x="60" y="74" fill="#E5B25D" fontSize="5.5" fontWeight="bold" fontFamily="monospace" letterSpacing="0.18em" textAnchor="middle" opacity="0.9">AI SWARM OS</text>
            </svg>
          </div>
        </div>

        {/* Traditional navigation */}
        <nav 
          className="hidden md:flex flex-wrap items-center gap-x-4 gap-y-1.5"
          style={{
            width: "100%",
            maxWidth: "785.8px",
            height: "44px",
            paddingLeft: "5px",
            paddingRight: "22px",
            fontSize: "12px",
            lineHeight: "41px",
            fontWeight: "normal",
            textDecorationLine: "none",
            fontFamily: "Inter, sans-serif",
            marginLeft: "1px",
            color: "#f1f3f7"
          }}
        >
          <button
            onClick={() => setActiveScreen("landing")}
            className={`hover:text-white cursor-pointer transition-colors text-[#f2fbf4] ${activeScreen === "landing" ? "underline underline-offset-4" : ""}`}
          >
            Homepage
          </button>
          <button
            onClick={() => {
              setActiveScreen("dashboard");
              setDashboardTab("ai_network");
            }}
            className={`hover:text-white cursor-pointer transition-colors text-[#f5f6ff] ${activeScreen === "dashboard" && dashboardTab === "ai_network" ? "underline underline-offset-4" : ""}`}
          >
            AI Swarm
          </button>
          <button
            onClick={() => {
              setActiveScreen("dashboard");
              setDashboardTab("trust_ledger");
            }}
            className={`hover:text-white cursor-pointer transition-colors text-[#eef1f6] ${activeScreen === "dashboard" && dashboardTab === "trust_ledger" ? "underline underline-offset-4" : ""}`}
          >
            Trust Layer
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                setActiveScreen("login");
              } else {
                setActiveScreen("dashboard");
                setDashboardTab("brand_hub");
              }
            }}
            className={`hover:text-white cursor-pointer transition-colors text-[#f0f2f6] ${activeScreen === "dashboard" && dashboardTab === "brand_hub" ? "underline underline-offset-4" : ""}`}
          >
            Brand Hub
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                setActiveScreen("login");
              } else {
                setActiveScreen("dashboard");
                setDashboardTab("creator_hub");
              }
            }}
            className={`hover:text-white cursor-pointer transition-colors text-[#f1f4f8] ${activeScreen === "dashboard" && dashboardTab === "creator_hub" ? "underline underline-offset-4" : ""}`}
          >
            Creator Hub
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                setActiveScreen("login");
              } else {
                setActiveScreen("dashboard");
                setDashboardTab("campaign");
              }
            }}
            className={`hover:text-white cursor-pointer transition-colors ${activeScreen === "dashboard" && dashboardTab === "campaign" ? "underline underline-offset-4" : ""}`}
          >
            Campaign Hub
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                setActiveScreen("login");
              } else {
                setActiveScreen("dashboard");
                setDashboardTab("analytics");
              }
            }}
            className={`hover:text-white cursor-pointer transition-colors ${activeScreen === "dashboard" && dashboardTab === "analytics" ? "underline underline-offset-4" : ""}`}
          >
            Analytics
          </button>
          <button
            onClick={() => {
              setActiveScreen("landing");
              setTimeout(() => {
                document.getElementById("architecture-section")?.scrollIntoView({ behavior: "smooth" });
              }, 120);
            }}
            className="hover:text-white cursor-pointer transition-colors"
          >
            Architecture
          </button>
          <button
            onClick={() => {
              setActiveScreen("landing");
              setTimeout(() => {
                document.getElementById("pricing-section")?.scrollIntoView({ behavior: "smooth" });
              }, 120);
            }}
            className="hover:text-white cursor-pointer transition-colors"
          >
            Pricing
          </button>
          <button
            onClick={() => {
              setActiveScreen("landing");
              setTimeout(() => {
                document.getElementById("about-section")?.scrollIntoView({ behavior: "smooth" });
              }, 120);
            }}
            className="hover:text-white cursor-pointer transition-colors"
          >
            About
          </button>
        </nav>

        {/* Dynamic User Session Metadata / CTA switches */}
        <div className="flex items-center gap-2 md:gap-4">
          {/* Header Bell Notification Center toggle */}
          <button
            onClick={() => {
              setShowNotifications(!showNotifications);
              setHasNewNotifications(false);
            }}
            className="relative p-2 md:p-2.5 rounded-lg bg-white hover:bg-soft-cream border border-soft-warm-gray text-charcoal hover:text-gold transition-all duration-300 cursor-pointer flex items-center justify-center group shadow-sm"
            title="Notification Center"
          >
            <Bell className={`w-4 h-4 transition-transform duration-300 group-hover:scale-110 ${hasNewNotifications ? "animate-bounce text-[#B5935B]" : "text-charcoal"}`} />
            {hasNewNotifications && (
              <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
              </span>
            )}
          </button>

          {currentUser ? (
            <div className="flex items-center gap-2 md:gap-3 border-l border-soft-warm-gray pl-2 md:pl-4">
              <div className="hidden sm:flex flex-col items-end text-xs">
                <span className="text-[#2D3E33] font-bold font-sans flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  {currentUser.name}
                  {currentUser.type === "brand" ? (
                    <span className="inline-flex items-center justify-center w-3 h-3 rounded-full bg-amber-500 text-white font-black text-[7px]" title="Elite Verified Brand Partner">✦</span>
                  ) : (
                    <span className="inline-flex items-center justify-center w-3 h-3 rounded-full bg-emerald-600 text-white text-[8px]" title="Identity Verified Creator Check">✓</span>
                  )}
                </span>
                <span className="text-[9px] font-mono text-gray-400">
                  {currentUser.type === "brand" ? "Verified Brand Partner" : `@${currentUser.handle || "creative"}`}
                </span>
              </div>
              
              {/* Initials fallback or image */}
              {currentUser.avatar.startsWith("http") ? (
                <img
                  src={currentUser.avatar}
                  className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover border border-[#B5935B] shadow-sm"
                  alt="Account Node"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              ) : (
                <div className="w-8 h-8 md:w-10 md:h-10 rounded-full bg-[#E4E2D9] border border-[#B5935B] flex items-center justify-center font-serif italic font-bold text-[#B5935B] text-xs md:text-base shadow-sm">
                  {currentUser.avatar}
                </div>
              )}
              
              <button
                onClick={() => {
                  setCurrentUser(null);
                  setActiveScreen("landing");
                }}
                className="text-[9px] md:text-[10px] font-mono text-[#B5935B] hover:text-red-500 font-bold transition-colors cursor-pointer border border-[#B5935B]/20 rounded px-1.5 md:px-2 py-0.5 whitespace-nowrap"
                title="Sign Out Session"
              >
                Sign Out
              </button>
            </div>
          ) : (
            <div className="flex gap-1.5 md:gap-2">
              <button
                onClick={() => {
                  setActiveScreen("login");
                }}
                className="bg-[#EBE4DC] hover:bg-[#DFD7CE] text-charcoal px-2.5 md:px-3.5 py-1.5 md:py-2 rounded-lg text-[10px] md:text-xs font-mono font-semibold transition-all border border-soft-warm-gray cursor-pointer"
              >
                Sign In
              </button>
              <button
                onClick={() => {
                  setActiveScreen("login");
                }}
                className="hidden sm:block bg-[#fcf8f8] text-[#080707] hover:bg-[#FAF8F5] px-3 md:px-4 py-1.5 md:py-2 rounded-lg text-[10px] md:text-xs font-mono font-semibold transition-all shadow-sm cursor-pointer whitespace-nowrap"
                style={{ backgroundColor: "#fcf8f8", color: "#080707" }}
              >
                Connect DID
              </button>
            </div>
          )}

          {/* Mobile Menu Toggle button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 bg-white/10 hover:bg-white/20 text-[#FAF8F5] hover:text-[#d49623] rounded-lg transition-colors border border-white/10 cursor-pointer flex items-center justify-center shadow-sm"
            aria-label="Toggle Navigation Screen"
          >
            {mobileMenuOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* MOBILE NAV DRAWER */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-b border-soft-warm-gray bg-[#1c3e24] w-full z-40 sticky top-[80px] shadow-lg overflow-hidden"
          >
            <div className="flex flex-col gap-1 px-6 py-4 font-mono text-[11px] text-[#f1f3f7]">
              <button
                onClick={() => {
                  setActiveScreen("landing");
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-[#f2fbf4] ${activeScreen === "landing" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Homepage
              </button>
              <button
                onClick={() => {
                  setActiveScreen("dashboard");
                  setDashboardTab("ai_network");
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-[#f5f6ff] ${activeScreen === "dashboard" && dashboardTab === "ai_network" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ AI Swarm
              </button>
              <button
                onClick={() => {
                  setActiveScreen("dashboard");
                  setDashboardTab("trust_ledger");
                  setMobileMenuOpen(false);
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-[#eef1f6] ${activeScreen === "dashboard" && dashboardTab === "trust_ledger" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Trust Layer Ledger
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (!currentUser) {
                    setActiveScreen("login");
                  } else {
                    setActiveScreen("dashboard");
                    setDashboardTab("brand_hub");
                  }
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-[#f0f2f6] ${activeScreen === "dashboard" && dashboardTab === "brand_hub" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Brand Hub
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (!currentUser) {
                    setActiveScreen("login");
                  } else {
                    setActiveScreen("dashboard");
                    setDashboardTab("creator_hub");
                  }
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-[#f1f4f8] ${activeScreen === "dashboard" && dashboardTab === "creator_hub" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Creator Hub
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (!currentUser) {
                    setActiveScreen("login");
                  } else {
                    setActiveScreen("dashboard");
                    setDashboardTab("campaign");
                  }
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors ${activeScreen === "dashboard" && dashboardTab === "campaign" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Campaign Escrows
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  if (!currentUser) {
                    setActiveScreen("login");
                  } else {
                    setActiveScreen("dashboard");
                    setDashboardTab("analytics");
                  }
                }}
                className={`text-left py-2 px-3 rounded hover:bg-white/10 transition-colors ${activeScreen === "dashboard" && dashboardTab === "analytics" ? "font-bold text-gold bg-white/5" : ""}`}
              >
                ➔ Analytics View
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setActiveScreen("landing");
                  setTimeout(() => {
                    document.getElementById("architecture-section")?.scrollIntoView({ behavior: "smooth" });
                  }, 120);
                }}
                className="text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-slate-300"
              >
                ➔ System Architecture
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setActiveScreen("landing");
                  setTimeout(() => {
                    document.getElementById("pricing-section")?.scrollIntoView({ behavior: "smooth" });
                  }, 120);
                }}
                className="text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-slate-300"
              >
                ➔ System Pricing Plan
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  setActiveScreen("landing");
                  setTimeout(() => {
                    document.getElementById("about-section")?.scrollIntoView({ behavior: "smooth" });
                  }, 120);
                }}
                className="text-left py-2 px-3 rounded hover:bg-white/10 transition-colors text-slate-300"
              >
                ➔ About & Custodians
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MAIN CONTAINER */}
      <main className="flex-1 py-4 sm:py-8 px-4 sm:px-6 max-w-7xl mx-auto w-full overflow-x-hidden">
        <AnimatePresence mode="wait">
          {/* VIEW 0: SECURE GATEWAY LOGIN */}
          {activeScreen === "login" && (
            <motion.div
              key="login"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="py-4"
            >
              <LoginGateway
                onLoginSuccess={(u) => {
                  setCurrentUser(u);
                  setActiveScreen("dashboard");
                  if (u.type === "brand") {
                    setDashboardTab("brand_hub");
                  } else {
                    setDashboardTab("creator_hub");
                  }
                }}
                onCancel={() => setActiveScreen("landing")}
              />
            </motion.div>
          )}
          
          {/* VIEW 1: PREMIUM SaaS LANDING HOMEPAGE */}
          {activeScreen === "landing" && (
            <motion.div 
              key="landing"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.2 }}
              className="space-y-16 p-4 sm:p-6 md:p-10 rounded-3xl"
              style={{
                background: "rgba(255, 255, 255, 0.45)",
                backdropFilter: "blur(16px)",
                WebkitBackdropFilter: "blur(16px)",
                border: "1px solid rgba(255, 255, 255, 0.3)",
                boxShadow: "0 8px 32px 0 rgba(0, 0, 0, 0.06)"
              }}
            >
            
            {/* HERO MODULE */}
            <div 
              className="text-center py-8 px-6 md:px-10 max-w-3xl mx-auto space-y-4 rounded-3xl transition-transform duration-500 hover:scale-[1.02]" 
              style={{ 
                background: "linear-gradient(135deg, rgba(255, 255, 255, 0.55) 0%, rgba(255, 255, 255, 0.2) 100%)", 
                backdropFilter: "blur(24px)", 
                WebkitBackdropFilter: "blur(24px)",
                border: "1px solid rgba(255, 255, 255, 0.5)", 
                boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.15), inset 0 1px 1px rgba(255, 255, 255, 0.8), inset 0 -4px 10px rgba(0, 0, 0, 0.04)"
              }}
            >
              <span className="text-xs font-mono tracking-widest text-[#A68042] uppercase block mb-1 underline">
                WHERE TRUST MEETS INFLUENCE. POWERED BY AI.
              </span>
              <h2 className="font-serif text-4xl sm:text-5xl md:text-6xl text-charcoal tracking-tight leading-tight no-underline italic">
                The Future of <span className="whitespace-nowrap inline-block">Brand-Creator</span> Collaboration
              </h2>
              <p className="text-sm text-[#555353] leading-relaxed font-sans max-w-xl mx-auto" style={{ color: "#555353" }}>
                AI-Powered Matching. Trust-Driven Collaboration. Intelligent Campaign Execution. Secure your marketing pools with cryptographic verification and zero-knowledge audits.
              </p>
              
              <div className="pt-4 flex flex-wrap gap-3 justify-center">
                <button
                  onClick={() => {
                    if (!currentUser) {
                      setActiveScreen("login");
                    } else {
                      setActiveScreen("dashboard");
                      setDashboardTab("brand_hub");
                    }
                  }}
                  className="bg-charcoal text-[#FAF8F5] hover:bg-forest-green transition-all px-6 py-3 rounded-xl text-xs font-sans font-bold shadow-luxury cursor-pointer"
                >
                  See Creator Match Demo
                </button>
                <button
                  onClick={() => {
                    if (!currentUser) {
                      setActiveScreen("login");
                    } else {
                      setActiveScreen("dashboard");
                      setDashboardTab("creator_hub");
                    }
                  }}
                  className="bg-[#EBE4DC] hover:bg-[#DFD7CE] text-charcoal transition-all px-6 py-3 rounded-xl text-xs font-sans font-bold border border-soft-warm-gray cursor-pointer"
                >
                  Find Opportunities
                </button>
              </div>
            </div>

            {/* ROLE SELECTION MODULE */}
            <div className="bg-soft-cream/40 p-6 md:p-8 rounded-2xl border-0" style={{ borderColor: "#ecf6ee", borderWidth: "0px" }}>
              <div className="text-center mb-6">
                <span className="text-[10px] font-mono text-[#A68042] tracking-wider uppercase">DYNAMIC SWITCHING INTERFACE</span>
                <h3 className="font-serif text-2xl text-charcoal mt-1">Select Your Core Objective</h3>
                <p className="text-xs text-gray-400 mt-1">Select key context tabs to adapt the dynamic matching previews on-the-fly.</p>
              </div>

              {/* Toggle switch keys */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
                <button
                  onClick={() => setHomepageRole("brand")}
                  className={`p-6 rounded-xl border text-left transition-all ${
                    homepageRole === "brand"
                      ? "bg-white border-gold shadow-luxury-hover ring-1 ring-gold"
                      : "bg-white/40 hover:bg-white border-soft-warm-gray"
                  }`}
                >
                  <Building className="w-8 h-8 text-gold mb-3" />
                  <h4 className="font-serif text-lg font-bold text-charcoal">I Am A Brand</h4>
                  <p className="text-xs text-gray-500 mt-1">Find vetted creators, scan audience fraud ratios, and draft automated smart contracts.</p>
                </button>

                <button
                  onClick={() => setHomepageRole("creator")}
                  className={`p-6 rounded-xl border text-left transition-all ${
                    homepageRole === "creator"
                      ? "bg-white border-[#1C3E24] shadow-luxury-hover ring-1 ring-forest-green"
                      : "bg-white/40 hover:bg-white border-soft-warm-gray"
                  }`}
                >
                  <User className="w-8 h-8 text-[#1C3E24] mb-3" />
                  <h4 className="font-serif text-lg font-bold text-charcoal">I Am A Creator</h4>
                  <p className="text-xs text-gray-500 mt-1">Verify social metrics, bid on secure brand budgets, and construct reputation timelines.</p>
                </button>
              </div>

              {/* DYNAMIC HOMEPAGE INTERACTIVE PREVIEW WIDGET */}
              <div className="mt-8">
                {homepageRole === "brand" ? (
                  <div className="bg-white rounded-xl border border-soft-warm-gray p-6 shadow-luxury">
                    <div className="border-b border-soft-cream pb-4 mb-4 flex justify-between items-center flex-wrap gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-gold uppercase font-bold flex items-center gap-1">
                          <Cpu className="w-3.5 h-3.5" /> Interactive Agent Matching Preview
                        </span>
                        <h4 className="font-serif text-lg font-bold text-charcoal mt-1">Simulate Brand Matching Discovery</h4>
                      </div>
                      <span className="text-[10px] font-mono text-gray-400 font-bold bg-soft-cream px-2.5 py-0.5 rounded">
                        10-Sec Demo Box
                      </span>
                    </div>

                    <form onSubmit={handleRunMatchMaker} className="grid grid-cols-1 sm:grid-cols-4 gap-3 mb-6 bg-[#FAF8F5] p-3 rounded-lg border border-soft-warm-gray text-xs">
                      <div>
                        <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Product/Brand Name</label>
                        <input
                          type="text"
                          className="w-full p-2 rounded bg-white border border-soft-warm-gray text-xs font-semibold"
                          value={inputBrandName}
                          onChange={(e) => setInputBrandName(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Product Variant</label>
                        <input
                          type="text"
                          className="w-full p-2 rounded bg-white border border-soft-warm-gray text-xs"
                          value={inputProductName}
                          onChange={(e) => setInputProductName(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Target Budget</label>
                        <input
                          type="text"
                          className="w-full p-2 rounded bg-white border border-soft-warm-gray text-xs text-emerald-800 font-bold font-mono"
                          value={inputBudget}
                          onChange={(e) => setInputBudget(e.target.value)}
                        />
                      </div>
                      <div className="flex items-end">
                        <button
                          type="submit"
                          disabled={isMatchingRunning}
                          className="w-full bg-charcoal hover:bg-forest-green text-white font-mono font-bold p-2 rounded transition-colors text-xs flex items-center justify-center gap-1"
                        >
                          {isMatchingRunning ? (
                            <RefreshCw className="animate-spin w-3.5 h-3.5" />
                          ) : (
                            <Sparkles className="w-3.5 h-3.5 text-gold animate-pulse" />
                          )}
                          {isMatchingRunning ? "Analyzing..." : "Find Creator Matches"}
                        </button>
                      </div>
                    </form>

                    {/* Matching Output Display */}
                    <div className="space-y-4">
                      <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block">MATCH RESULTS INDEXED BY DISCOVERY AGENT:</span>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {matchedResults.map((creator) => (
                          <div key={creator.id} className="p-4 border border-soft-cream rounded-lg hover:border-gold transition-colors space-y-3 flex flex-col justify-between">
                            <div className="flex justify-between items-start">
                              <div className="flex gap-2.5">
                                <img src={creator.avatar} alt={creator.name} className="w-10 h-10 rounded-lg object-cover" />
                                <div>
                                  <h4 className="font-serif font-bold text-sm text-charcoal">{creator.name}</h4>
                                  <span className="text-[10px] font-mono text-gray-400 block">{creator.handle}</span>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-[9px] text-gray-400 block uppercase">Trust Score</span>
                                <span className="font-serif font-bold text-[#1C3E24] text-base">{creator.trustScore.overall}</span>
                              </div>
                            </div>

                            <div className="grid grid-cols-3 gap-1 bg-soft-cream/30 p-2 rounded text-center text-[10px]">
                              <div>
                                <span className="text-[8px] text-gray-400 block">AUDIENCE</span>
                                <strong className="text-charcoal">{creator.followersCount}</strong>
                              </div>
                              <div>
                                <span className="text-[8px] text-gray-400 block">ENGAGEMENT</span>
                                <strong className="text-charcoal">{creator.engagementRate}%</strong>
                              </div>
                              <div>
                                <span className="text-[8px] text-gray-400 block">PRED. ROI</span>
                                <strong className="text-emerald-800">{creator.predictedROI}x</strong>
                              </div>
                            </div>
                            
                            {/* Explainable AI matching tag block */}
                            <div className="bg-[#FAF8F5] p-2 rounded text-[10px] text-gray-500 border border-gold/25 leading-relaxed">
                              <strong>Why Recommended?</strong> ✓ High Audience overlap (94%) • High content correlation to Earth Tone sustainable sportswear briefs.
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white rounded-xl border border-soft-warm-gray p-6 shadow-luxury">
                    <div className="border-b border-soft-cream pb-4 mb-4 flex justify-between items-center flex-wrap gap-2">
                      <div>
                        <span className="text-[10px] font-mono text-[#1C3E24] uppercase font-bold flex items-center gap-1">
                          <Briefcase className="w-3.5 h-3.5" /> High Paying Brand Campaigns Opportunities
                        </span>
                        <h4 className="font-serif text-lg font-bold text-charcoal mt-1">Recommended Opportunities for Creators</h4>
                      </div>
                      <span className="text-[10px] font-mono text-gray-400 font-bold bg-soft-cream px-2.5 py-0.5 rounded">
                        Simulate Apply Box
                      </span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {INITIAL_CAMPAIGNS.map((camp) => {
                        const isApplied = appliedCampaignId.includes(camp.id);
                        const isSaved = bookmarkedCampaignId.includes(camp.id);

                        return (
                          <div key={camp.id} className="p-4 border border-soft-cream rounded-lg hover:border-gold transition-colors flex flex-col justify-between">
                            <div>
                              <div className="flex justify-between items-start gap-2 mb-2">
                                <span className="text-[10px] font-mono text-gray-400 uppercase tracking-wider flex items-center gap-1">
                                  {camp.brandName}
                                  <span className="inline-flex items-center justify-center w-3 h-3 rounded-full bg-amber-500 text-white font-black text-[7px]" title="Elite Verified Brand Partner">✦</span>
                                </span>
                                <span className="text-[9px] bg-emerald-50 text-emerald-800 px-2 py-0.5 border border-emerald-100 rounded font-bold">
                                  {camp.predictedROI}x Predicted ROI
                                </span>
                              </div>
                              <h4 className="font-serif font-bold text-sm text-charcoal">{camp.title}</h4>
                              <p className="text-xs text-gray-500 mt-1 lines-clamp-2 leading-relaxed">{camp.description}</p>
                              
                              <div className="mt-2.5 font-mono text-[10px] text-gray-400 whitespace-nowrap">
                                Budget: <strong className="text-charcoal font-bold">₹{camp.budget.toLocaleString()}</strong>
                              </div>
                            </div>

                            <div className="flex gap-1.5 pt-3 border-t border-soft-cream mt-4">
                              <button
                                onClick={() => handleApplyCampaign(camp.id)}
                                disabled={isApplied}
                                className={`flex-1 py-1 px-3 rounded text-xs font-mono font-bold transition-all ${
                                  isApplied 
                                    ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                                    : "bg-charcoal text-white hover:bg-forest-green"
                                }`}
                              >
                                {isApplied ? "Applied (Pending Sync)" : "Apply to Campaign"}
                              </button>
                              <button
                                onClick={() => handleBookmarkCampaign(camp.id)}
                                className={`px-2.5 py-1 rounded border text-xs ${
                                  isSaved ? "bg-gold text-white border-gold" : "bg-white border-soft-warm-gray text-charcoal"
                                }`}
                              >
                                {isSaved ? "★ Saved" : "☆ Save"}
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* LIVE ACTIVITY TICKER (WOW FACTOR) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Live feed panel */}
              <div className="lg:col-span-8 bg-white rounded-2xl p-6 md:p-8 shadow-luxury" style={{ borderWidth: "0px" }}>
                <div className="flex items-center justify-between border-b border-soft-cream pb-4 mb-4">
                  <div className="flex items-center gap-2">
                    <Activity className="w-5 h-5 text-gold animate-bounce" />
                    <div>
                      <h4 className="font-serif text-lg font-bold text-charcoal">Ecosystem Live Activity Center</h4>
                      <p className="text-[10px] text-gray-400 font-mono">Live system consensus triggers mapped real-time</p>
                    </div>
                  </div>
                  <span className="text-[9px] font-mono text-emerald-800 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    NETWORK STEADY
                  </span>
                </div>

                <div className="space-y-4">
                  {activities.map((act) => (
                    <div key={act.id} className="p-3 bg-[#FAF8F5] rounded-xl border border-soft-warm-gray flex gap-3 items-start animate-fade-in">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping shrink-0 mt-2"></span>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-700 leading-relaxed font-sans">{act.text}</p>
                        <span className="text-[9px] font-mono text-gray-400 mt-1 block">{act.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: Premium Trust Card showcase */}
              <div className="lg:col-span-4 bg-white p-6 md:p-8 shadow-luxury flex flex-col justify-between align-stretch text-center font-sans space-y-6" style={{ borderWidth: "0px", borderRadius: "10px" }}>
                <div>
                  <span className="text-[9px] font-mono text-gray-400 uppercase tracking-widest block mb-2">IMMUTABLE TRUST SHOWCASE</span>
                  <div className="w-16 h-16 rounded-full bg-[#EFE9E1] flex items-center justify-center text-gold mx-auto text-2xl border border-soft-warm-gray shadow-sm">
                    🛡️
                  </div>
                  <h4 className="font-serif text-2xl text-charcoal mt-3">Aurexia Trust Rating</h4>
                  
                  <div className="text-4xl font-serif text-[#1C3E24] tracking-tight font-bold mt-2">96 / 100</div>
                  <span className="text-[10px] font-mono text-gray-400 uppercase block mt-1 tracking-wider">ECOSYSTEM PLATINUM DEEP AUDIT</span>
                </div>

                <div className="text-left text-xs text-gray-500 space-y-2 border-t border-soft-cream pt-4 font-sans leading-relaxed">
                  <div className="flex justify-between border-b border-[#FAF8F5] pb-1">
                    <span>✓ Identity status:</span>
                    <strong className="text-charcoal">DID Verified</strong>
                  </div>
                  <div className="flex justify-between border-b border-[#FAF8F5] pb-1">
                    <span>✓ Audience Check:</span>
                    <strong className="text-[#1C3E24]">97.4% Human</strong>
                  </div>
                  <div className="flex justify-between border-b border-[#FAF8F5] pb-1">
                    <span>✓ Fraud Threat:</span>
                    <strong className="text-charcoal font-sans text-[10px] bg-emerald-50 text-emerald-800 px-1 py-0.5 rounded">Low Risk</strong>
                  </div>
                </div>

                <div className="text-[9px] font-mono text-gray-400 italic">
                  Escrow, verification benchmarks, and performance indexes are anchored onto our Polygon Ledger.
                </div>
              </div>
            </div>

            {/* BRAND VALUE INGENUITY SYSTEM GATEWAYS */}
            <div className="space-y-4">
              <h3 className="font-serif text-2xl text-charcoal text-center underline font-bold italic">Explore the Aurexia OS Modules</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <button
                  onClick={() => {
                    setActiveScreen("dashboard");
                    setDashboardTab("ai_network");
                  }}
                  className="p-5 bg-white hover:bg-soft-cream/30 border text-left rounded-xl transition-all shadow-luxury hover:shadow-luxury-hover block group cursor-pointer"
                  style={{ borderColor: "#040404" }}
                >
                  <div className="w-8 h-8 rounded-lg bg-[#EFE9E1] flex items-center justify-center text-lg text-gold mb-3 group-hover:scale-105 transition-transform">🧠</div>
                  <h4 className="font-serif text-base font-bold text-charcoal">AI Swarm Network</h4>
                  <p className="text-xs text-gray-500 mt-1 font-sans">Examine the narrow-AI autonomous swarm orchestrating budget checks, discovery feeds, and fraud auditing.</p>
                </button>

                <button
                  onClick={() => {
                    setActiveScreen("dashboard");
                    setDashboardTab("trust_ledger");
                  }}
                  className="p-5 bg-white hover:bg-soft-cream/30 border text-left rounded-xl transition-all shadow-luxury hover:shadow-luxury-hover block group cursor-pointer"
                  style={{ borderColor: "#0a0a0a" }}
                >
                  <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-soft-warm-gray flex items-center justify-center text-lg text-charcoal mb-3 group-hover:scale-105 transition-transform">⛓️</div>
                  <h4 className="font-serif text-base font-bold text-charcoal">Trust Layer Ledger</h4>
                  <p className="text-xs text-gray-500 mt-1 font-sans">Browse decentralized identifiers (DIDs), verification logs, on-chain smart agreements, and Zero-knowledge math.</p>
                </button>

                <button
                  onClick={() => {
                    setActiveScreen("dashboard");
                    setDashboardTab("brand_hub");
                  }}
                  className="p-5 bg-white hover:bg-soft-cream/30 border text-left rounded-xl transition-all shadow-luxury hover:shadow-luxury-hover block group cursor-pointer"
                  style={{ borderColor: "#090908" }}
                >
                  <div className="w-8 h-8 rounded-lg bg-[#EFE9E1] flex items-center justify-center text-lg text-[#1C3E24] mb-3 group-hover:scale-105 transition-transform">⚡</div>
                  <h4 className="font-serif text-base font-bold text-charcoal">Brand Control Hub</h4>
                  <p className="text-xs text-gray-500 mt-1 font-sans">Deploy briefings, view recommended matches, communicate with creators, and monitor budget spend schedules.</p>
                </button>

                <button
                  onClick={() => {
                    setActiveScreen("dashboard");
                    setDashboardTab("campaign");
                  }}
                  className="p-5 bg-white hover:bg-soft-cream/30 border text-left rounded-xl transition-all shadow-luxury hover:shadow-luxury-hover block group cursor-pointer"
                  style={{ borderColor: "#050505" }}
                >
                  <div className="w-8 h-8 rounded-lg bg-[#FAF8F5] border border-soft-warm-gray flex items-center justify-center text-lg text-charcoal mb-3 group-hover:scale-105 transition-transform">🎯</div>
                  <h4 className="font-serif text-base font-bold text-charcoal">Smart Contract Escrow</h4>
                  <p className="text-xs text-gray-500 mt-1 font-sans">Audit active campaign workflow structures, upload and approve draft asset files, and release payments automatically.</p>
                </button>
              </div>
            </div>

            {/* SECTION: ARCHITECTURE */}
            <div id="architecture-section" className="pt-8 border-t border-soft-warm-gray space-y-8 animate-fade-in scroll-mt-20">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-[10px] font-mono text-[#B5935B] uppercase tracking-widest font-bold">DECENTRALIZED WORKFLOW INTEGRITY</span>
                <h3 className="font-serif text-3xl text-charcoal">System Architecture Overview</h3>
                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  Aurexia OS coordinates autonomous smart contract escrows with multi-agent neural matches under zero-knowledge user verification layers.
                </p>
              </div>

              {/* Data-flow block rendering */}
              <div className="bg-white rounded-2xl border border-soft-warm-gray p-6 lg:p-8 shadow-luxury space-y-6">
                <span className="block text-[10px] font-mono text-gray-400 uppercase tracking-widest text-center">NETWORK PIPELINE & TRUST DECRYPT STREAM</span>

                {/* Flow Diagram (Horizontal on Desktop, Vertical on Mobile) */}
                <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center">
                  
                  <div className="p-4 bg-[#FAF8F5] rounded-xl border border-soft-warm-gray hover:border-[#1C3E24] transition-colors">
                    <div className="w-10 h-10 rounded-full bg-emerald-50 text-[#1C3E24] flex items-center justify-center text-lg font-bold mx-auto mb-2">1</div>
                    <h5 className="font-serif text-xs font-bold text-charcoal">Zero-Knowledge Verification</h5>
                    <p className="text-[10px] text-gray-400 font-sans mt-1">Authenticates identities without leaking sensitive banking or personal keys.</p>
                  </div>

                  <div className="text-gray-300 font-mono text-xs font-bold py-1">
                    <div className="hidden md:block text-[#080808]" style={{ color: "#080808" }}>───────▶</div>
                    <div className="md:hidden">▼</div>
                  </div>

                  <div className="p-4 bg-[#FAF8F5] rounded-xl border border-soft-warm-gray hover:border-[#B5935B] transition-colors">
                    <div className="w-10 h-10 rounded-full bg-amber-50 text-[#B5935B] flex items-center justify-center text-lg font-bold mx-auto mb-2">2</div>
                    <h5 className="font-serif text-xs font-bold text-charcoal">Multi-Agent Swarm Evaluation</h5>
                    <p className="text-[10px] text-gray-400 font-sans mt-1">Filters bot followings and forecasts real ROI yields programmatically.</p>
                  </div>

                  <div className="text-gray-300 font-mono text-xs font-bold py-1">
                    <div className="hidden md:block text-[#080808]" style={{ color: "#080808" }}>───────▶</div>
                    <div className="md:hidden">▼</div>
                  </div>

                  <div className="p-4 bg-[#FAF8F5] rounded-xl border border-soft-warm-gray hover:border-emerald-600 transition-colors">
                    <div className="w-10 h-10 rounded-full bg-blue-50 text-emerald-800 flex items-center justify-center text-lg font-bold mx-auto mb-2">3</div>
                    <h5 className="font-serif text-xs font-bold text-charcoal">Smart Ledger Escrow & Audit</h5>
                    <p className="text-[10px] text-gray-400 font-sans mt-1">Anchors creator outputs and releases payment upon zero-error content approval.</p>
                  </div>

                </div>

                {/* Bento Grid Features representing Architecture elements */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
                  <div className="p-5 border border-[#FAF8F5] bg-soft-cream/10 rounded-xl space-y-2">
                    <Layers className="w-5 h-5 text-[#B5935B]" />
                    <h4 className="font-serif font-bold text-sm text-charcoal">Dynamic Modular Abstraction</h4>
                    <p className="text-xs text-gray-500 font-sans leading-relaxed">
                      Our system decoupled backends to ensure database performance is isolated, supporting heavy traffic spikes without latency bottlenecks.
                    </p>
                  </div>

                  <div className="p-5 border border-[#FAF8F5] bg-soft-cream/10 rounded-xl space-y-2">
                    <Lock className="w-5 h-5 text-emerald-700" />
                    <h4 className="font-serif font-bold text-sm text-charcoal">ZK-Credential Shielding</h4>
                    <p className="text-xs text-gray-500 font-sans leading-relaxed">
                      Identity data utilizes public-key cryptography to prevent third-party profiling, letting entities control disclosure limits strictly.
                    </p>
                  </div>

                  <div className="p-5 border border-[#FAF8F5] bg-white rounded-xl space-y-2 col-span-1 md:col-span-2 lg:col-span-1" style={{ backgroundColor: "#ffffff" }}>
                    <Cpu className="w-5 h-5 text-[#1C3E24]" />
                    <h4 className="font-serif font-bold text-sm text-charcoal">Decentralized Trust Anchors</h4>
                    <p className="text-xs text-gray-500 font-sans leading-relaxed">
                      Core contract audits, payment releases, and creator reputation markers execute with multi-sig proof models on public blockchain.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* SECTION: PRICING */}
            <div id="pricing-section" className="pt-8 border-t border-soft-warm-gray space-y-8 animate-fade-in scroll-mt-20">
              <div className="text-center max-w-2xl mx-auto space-y-2">
                <span className="text-[10px] font-mono text-[#B5935B] uppercase tracking-widest font-bold">SYSTEM NODE LICENSING PLANS</span>
                <h3 className="font-serif text-3xl text-charcoal">Flexible Pricing Framework</h3>
                <p className="text-xs text-gray-500 font-sans leading-relaxed">
                  Start researching campaign forecasts in our sandbox or scale immediately with full cryptographic multi-agent automation.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
                
                {/* Free plan */}
                <div className="bg-white border border-soft-warm-gray rounded-2xl p-6 flex flex-col justify-between shadow-sm hover:shadow-luxury hover:border-gray-300 transition-all">
                  <div className="space-y-4">
                    <div>
                      <span className="text-[9px] font-mono text-gray-400 bg-gray-100 px-2 py-0.5 rounded font-bold uppercase">Basic Access</span>
                      <h4 className="font-serif text-xl font-bold text-charcoal mt-2">Dynamic Startup Node</h4>
                      <p className="text-xs text-gray-400 mt-1 font-sans">Ideal for small sandbox simulations and prototype campaigns.</p>
                    </div>

                    <div className="pt-2">
                      <span className="text-3xl font-serif font-bold text-charcoal">₹0</span>
                      <span className="text-xs text-gray-400 font-mono"> / free tier</span>
                    </div>

                    <ul className="text-xs text-gray-500 space-y-2 pt-2 border-t border-soft-cream font-sans">
                      <li className="flex items-center gap-1.5">✓ Standard Multi-Agent Matching Sandbox</li>
                      <li className="flex items-center gap-1.5">✓ 1 Active Smart Escrow Contract</li>
                      <li className="flex items-center gap-1.5">✓ Basic Bot Follower Ratio Indicator</li>
                      <li className="flex items-center gap-1.5">✓ Manual File Assets Upload & Review</li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={() => setActiveScreen("login")}
                      className="w-full py-2 border border-soft-warm-gray rounded-lg text-xs font-mono text-charcoal hover:bg-soft-cream/30 transition-all font-bold cursor-pointer"
                    >
                      Initialize Sandbox Node
                    </button>
                  </div>
                </div>

                {/* Popular Plan */}
                <div className="bg-white border-2 border-[#1C3E24] rounded-2xl p-6 flex flex-col justify-between shadow-luxury relative overflow-hidden transform scale-100 md:scale-105">
                  <div className="absolute top-0 right-0 bg-[#1C3E24] text-white text-[8px] font-mono font-bold px-3 py-1 uppercase rounded-bl-lg tracking-widest">
                    Recommended
                  </div>

                  <div className="space-y-4">
                    <div>
                      <span className="text-[9px] font-mono text-gold bg-amber-50 px-2 py-0.5 rounded font-bold uppercase">Full Capability Pack</span>
                      <h4 className="font-serif text-xl font-bold text-charcoal mt-2">Consortium Platform Key</h4>
                      <p className="text-xs text-gray-400 mt-1 font-sans">For professional marketing operators demanding fully verified audits.</p>
                    </div>

                    <div className="pt-2">
                      <span className="text-3xl font-serif font-bold text-[#1C3E24]">₹20,000</span>
                      <span className="text-xs text-gray-400 font-mono"> / month (Billed Annually)</span>
                    </div>

                    <ul className="text-xs text-gray-500 space-y-2 pt-2 border-t border-[#1C3E24]/10 font-sans font-medium">
                      <li className="flex items-center gap-1.5 text-charcoal">✓ Unlimited Multi-Agent Matches</li>
                      <li className="flex items-center gap-1.5 text-charcoal">✓ Unlimited Active Escrow Structures</li>
                      <li className="flex items-center gap-1.5 text-charcoal">✓ 99.9% Human Fraud Spot Auditor</li>
                      <li className="flex items-center gap-1.5 text-charcoal">✓ Dynamic Content Translating Messenger</li>
                      <li className="flex items-center gap-1.5 text-charcoal">✓ Priority Node Execution Pipeline</li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={() => setActiveScreen("login")}
                      className="w-full py-2.5 bg-[#1C3E24] hover:bg-forest-green text-[#FAF8F5] rounded-lg text-xs font-mono transition-all font-bold cursor-pointer"
                    >
                      Deploy Consortium Node
                    </button>
                  </div>
                </div>

                {/* Premium Plan */}
                <div className="bg-white border border-soft-warm-gray rounded-2xl p-6 flex flex-col justify-between shadow-sm hover:shadow-luxury hover:border-gray-300 transition-all">
                  <div className="space-y-4">
                    <div>
                      <span className="text-[9px] font-mono text-gray-400 bg-gray-100 px-2 py-0.5 rounded font-bold uppercase">Enterprise Sovereignty</span>
                      <h4 className="font-serif text-xl font-bold text-charcoal mt-2">Sovereign Grid Node</h4>
                      <p className="text-xs text-gray-400 mt-1 font-sans">For enterprise companies requiring dedicated security & rules.</p>
                    </div>

                    <div className="pt-2">
                      <span className="text-3xl font-serif font-bold text-charcoal">On Request</span>
                      <span className="text-xs text-gray-400 font-mono"> / Custom SLA</span>
                    </div>

                    <ul className="text-xs text-gray-500 space-y-2 pt-2 border-t border-soft-cream font-sans">
                      <li className="flex items-center gap-1.5">✓ Designated Audit Validator Miners</li>
                      <li className="flex items-center gap-1.5">✓ Custom-designed Match Heuristics</li>
                      <li className="flex items-center gap-1.5">✓ Bespoke Smart Escrow Contract Rules</li>
                      <li className="flex items-center gap-1.5">✓ 24/7 Priority Support & Onsite Training</li>
                      <li className="flex items-center gap-1.5">✓ Full Telemetry Logs & Relational DB Mirrors</li>
                    </ul>
                  </div>

                  <div className="pt-6">
                    <button
                      onClick={() => {
                        const contactEl = document.getElementById("contact-section");
                        if (contactEl) {
                          contactEl.scrollIntoView({ behavior: "smooth" });
                        }
                      }}
                      className="w-full py-2 border border-soft-warm-gray rounded-lg text-xs font-mono text-charcoal hover:bg-soft-cream/30 transition-all font-bold cursor-pointer"
                    >
                      Query Core Custodians
                    </button>
                  </div>
                </div>

              </div>
            </div>

            {/* SECTION: ABOUT */}
            <div id="about-section" className="pt-8 border-t border-soft-warm-gray space-y-8 animate-fade-in scroll-mt-20">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center max-w-5xl mx-auto">
                
                <div className="lg:col-span-5 space-y-4">
                  <span className="text-[10px] font-mono text-[#B5935B] uppercase tracking-widest font-bold">REBUILDING THE INFLUENCE INDUSTRY</span>
                  <h3 className="font-serif text-3xl text-charcoal leading-tight">About Aurexia OS</h3>
                  <p className="text-xs text-gray-500 font-sans leading-relaxed">
                    Aurexia OS was founded by a coalition of consensus researchers, multi-agent system engineers, and luxury lifestyle architects. Our focus is to engineer standard compliance structures that eliminate bot networks, delay risk, and opaque contracts in global creator advertising.
                  </p>
                  <p className="text-xs text-gray-500 font-sans leading-relaxed">
                    Operated under <strong>Aurexia OS Trust Systems Corp.</strong>, we deliver enterprise-ready tools integrated with blockchain reputation layers, providing transparent benchmarks to track real engagement rates and marketing asset deliverables with zero ambiguity.
                  </p>
                  
                  {/* Stats highlights */}
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div className="p-3 bg-white rounded-xl border border-soft-warm-gray">
                      <span className="text-lg font-serif font-bold text-[#1C3E24]">₹4+ Crore</span>
                      <span className="text-[9px] font-mono text-gray-400 block uppercase">Escrows Handled</span>
                    </div>
                    <div className="p-3 bg-white rounded-xl border border-soft-warm-gray">
                      <span className="text-lg font-serif font-bold text-[#B5935B]">99.8%</span>
                      <span className="text-[9px] font-mono text-gray-400 block uppercase">SLA Delivery Audit</span>
                    </div>
                  </div>
                </div>

                <div id="contact-section" className="lg:col-span-7 bg-[#FAF8F5] border border-soft-warm-gray p-6 rounded-2xl space-y-4">
                  <div className="border-b border-soft-cream pb-3">
                    <h4 className="font-serif text-lg font-bold text-charcoal">Core Node Communication Panel</h4>
                    <p className="text-[10px] text-gray-400 font-sans">Reach out directly to our operations room for integration audits and onprem support.</p>
                  </div>

                  <form onSubmit={(e) => { e.preventDefault(); alert("System Message: Message signed and recorded on Aurexia Local Node. We will respond within 4 hours."); }} className="space-y-3 font-sans text-xs">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Company/Creator Name</label>
                        <input required type="text" placeholder="e.g. Nike Operations" className="w-full p-2 bg-white border border-soft-warm-gray rounded text-xs focus:ring-1 focus:ring-gold focus:outline-none" />
                      </div>
                      <div>
                        <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">SSO Email Address</label>
                        <input required type="email" placeholder="operations@nike.in" className="w-full p-2 bg-white border border-soft-warm-gray rounded text-xs focus:ring-1 focus:ring-gold focus:outline-none" />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Inquiry Purpose</label>
                      <select className="w-full p-2 bg-white border border-soft-warm-gray rounded text-xs focus:ring-1 focus:ring-gold focus:outline-none">
                        <option>Request On-Prem Multi-Sovereign Grid Node SLA</option>
                        <option>Audit Existing Campaign Escrow Contract Integrity</option>
                        <option>Vetting Partnership / Venture Alliances</option>
                        <option>General Tech Support & API Integration</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[9px] font-mono text-gray-400 uppercase mb-1">Details secure key requirements</label>
                      <textarea rows={2} placeholder="Explain your scale objectives..." className="w-full p-2 bg-white border border-soft-warm-gray rounded text-xs focus:ring-1 focus:ring-gold focus:outline-none"></textarea>
                    </div>

                    <div className="flex justify-between items-center pt-2">
                      <span className="text-[9px] font-mono text-gray-400 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-800" /> AES-256 Client-Side Protected
                      </span>
                      <button type="submit" className="px-4 py-2 bg-charcoal hover:bg-[#1C3E24] text-white font-mono text-[10px] font-bold uppercase rounded tracking-wider shadow-sm transition-all cursor-pointer">
                        Sign & Transmit Message
                      </button>
                    </div>
                  </form>
                </div>

              </div>
            </div>

          </motion.div>
        )}

        {/* VIEW 2: EXECUTIVE STARTUP CONTROL CENTER DASHBOARD */}
        {activeScreen === "dashboard" && (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.2 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start w-full"
          >
            
            {/* Left sidebar dashboard navigation router */}
            <div className="lg:col-span-3 bg-white border border-soft-warm-gray rounded-xl p-4 shadow-luxury space-y-3.5">
              <div className="border-b border-soft-cream pb-3 text-center lg:text-left">
                <span className="text-[10px] font-mono text-gray-400 uppercase tracking-widest block">CONTROL PANEL</span>
                <h3 className="font-serif text-lg font-bold text-charcoal">Ecosystem Modules</h3>
              </div>

              <div className="flex flex-wrap lg:flex-col gap-1.5 justify-center lg:justify-start font-mono text-xs font-semibold text-gray-500">
                <button
                  onClick={() => setDashboardTab("brand_hub")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "brand_hub" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  📡 Brand Discovery Hub
                </button>
                <button
                  onClick={() => setDashboardTab("creator_hub")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "creator_hub" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  💅 Creator Portfolio Hub
                </button>
                <button
                  onClick={() => setDashboardTab("campaign")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "campaign" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  🔒 Escrow Contract Hub
                </button>
                <button
                  onClick={() => setDashboardTab("messaging")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "messaging" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  💬 Translating Messenger
                </button>
                <button
                  onClick={() => setDashboardTab("ai_network")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "ai_network" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  🧠 Multi-Agent AI Swarm
                </button>
                <button
                  onClick={() => setDashboardTab("trust_ledger")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "trust_ledger" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  ⛓️ Trust Layer Ledger
                </button>
                <button
                  onClick={() => setDashboardTab("analytics")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "analytics" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  📈 Data & Yield Analytics
                </button>
                <button
                  onClick={() => setDashboardTab("comparison")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "comparison" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  ⚖️ Side-by-Side Comparator
                </button>
                <button
                  onClick={() => setDashboardTab("onboarding")}
                  className={`w-full text-left p-2.5 rounded-lg transition-all flex items-center gap-2 cursor-pointer ${
                    dashboardTab === "onboarding" ? "bg-charcoal text-white font-bold" : "hover:bg-soft-cream/40"
                  }`}
                >
                  🤝 Onboarding Simulator
                </button>
              </div>
            </div>

            {/* Right container: Dynamic component mount */}
            <div className="lg:col-span-9 space-y-6">
              
              {dashboardTab === "ai_network" && <AIAgentNetwork />}
              
              {dashboardTab === "trust_ledger" && <TrustIntelligence />}

              {dashboardTab === "comparison" && (
                <ComparatorView 
                  onUpgradeRequest={() => {
                    // Alert that we are triggering show_aistudio_ui flow
                    const upgradeMsg = document.createElement("div");
                    upgradeMsg.innerHTML = "⚠️ Aurexia Secure Gateway is requesting elite premium keys. Proceeding to authorize Paid Model Flow parameter sync...";
                    upgradeMsg.className = "fixed bottom-5 right-5 bg-charcoal text-[#FAF8F5] p-4 rounded-lg font-mono text-xs z-50 border border-gold shadow-luxury max-w-sm";
                    document.body.appendChild(upgradeMsg);
                    setTimeout(() => upgradeMsg.remove(), 6000);
                  }}
                />
              )}
              
              {/* Private restricted tabs login fallback */}
              {["brand_hub", "creator_hub", "campaign", "messaging", "analytics"].includes(dashboardTab) && !currentUser ? (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-[#FAF8F5] border border-amber-500/20 text-[#B5935B] px-4 py-3 rounded-xl flex items-center gap-3 text-xs font-mono shadow-sm">
                    <AlertTriangle className="w-4.5 h-4.5 text-amber-500 shrink-0" />
                    <span>SECURE ENVIRONMENT DECRYPT LOCK: The selected space requires an authenticated Aurexia Administrator handshake. Please configure identity options below to proceed.</span>
                  </div>
                  <LoginGateway
                    onLoginSuccess={(u) => {
                      setCurrentUser(u);
                    }}
                  />
                </div>
              ) : (
                <>
                  {dashboardTab === "brand_hub" && (
                    <BrandDashboardView
                      onSendMessage={(id) => {
                        setChatCreatorId(id);
                        setDashboardTab("messaging");
                      }}
                      onSelectCreator={(creator) => {
                        setSelectedCreatorProfile(creator);
                        setDashboardTab("creator_hub");
                      }}
                    />
                  )}
                  
                  {dashboardTab === "creator_hub" && (
                    <CreatorDashboardView creatorId={selectedCreatorProfile.id} />
                  )}
                  
                  {dashboardTab === "campaign" && <CampaignHubView />}
                  
                  {dashboardTab === "messaging" && (
                    <MessagingCenterView initialCreatorId={chatCreatorId} />
                  )}
                  
                  {dashboardTab === "analytics" && <AnalyticsView />}
                </>
              )}

              {dashboardTab === "onboarding" && <OnboardingHelper />}

            </div>

          </motion.div>
        )}
        </AnimatePresence>

      </main>

      {/* STICKY SIDE AI COPILOT COMPANION PANEL (Every major screen has dynamic suggestions) */}
      {aiCopilotOpened && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-charcoal text-white rounded-2xl border border-black shadow-luxury-deep p-5 animate-fade-in font-sans">
          <div className="flex justify-between items-center border-b border-gray-800 pb-2 mb-3">
            <span className="text-[10px] font-mono text-gold font-bold uppercase tracking-widest flex items-center gap-1.5">
              <Bot className="w-4 h-4 text-gold" /> AUREXIA ACTIVE COPILOT
            </span>
            <button
              onClick={() => setAiCopilotOpened(false)}
              className="text-gray-400 hover:text-white font-bold text-xs p-1"
            >
              ✕
            </button>
          </div>

          <div className="space-y-2.5 text-xs">
            <p className="text-gray-300 leading-relaxed font-sans">
              Based on your active view context, AUREXIA's swarm recommends the following optimizations:
            </p>
            <div className="bg-graphite p-2.5 rounded border border-gray-800 font-mono text-[10px] leading-relaxed text-[#C5A059] flex items-start gap-1.5">
              <span>💡</span>
              <span>We audit and score matching profiles across 8 neural factors offline. Brand escrow pools are fully protected by multi-signature blocktime validators on Polygon.</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setActiveScreen("dashboard");
                  setDashboardTab("onboarding");
                }}
                className="w-full py-1.5 bg-gold text-charcoal hover:bg-white hover:text-charcoal transition-all text-[11px] font-mono font-bold rounded"
              >
                Onboard verified Node
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating trigger button to open copilot if closed */}
      {!aiCopilotOpened && (
        <button
          onClick={() => setAiCopilotOpened(true)}
          className="fixed bottom-6 right-6 z-50 bg-charcoal hover:bg-forest-green text-gold hover:text-white p-3.5 rounded-full border border-black shadow-luxury-deep font-bold transition-all cursor-pointer flex items-center justify-center gap-1.5 text-xs font-mono"
        >
          <Bot className="w-5 h-5 animate-bounce" /> Copilot Help
        </button>
      )}

      {/* Floating Bell Notifications Toggle (positioned just above the Copilot Help button) */}
      <button
        onClick={() => {
          setShowNotifications(!showNotifications);
          setHasNewNotifications(false);
        }}
        className={`fixed ${aiCopilotOpened ? "bottom-[340px]" : "bottom-24"} right-6 z-50 bg-[#FAF8F5] hover:bg-[#EBE4DC] active:bg-[#DFD7CE] text-charcoal p-3.5 rounded-full border border-[#B5935B]/40 shadow-luxury-deep font-bold transition-all duration-300 cursor-pointer flex items-center justify-center`}
        title="Ecosystem Alerts & Logs"
      >
        <Bell className={`w-5 h-5 ${hasNewNotifications ? "animate-bounce text-[#B5935B]" : "text-charcoal"}`} />
        {hasNewNotifications && (
          <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5 items-center justify-center">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
          </span>
        )}
      </button>

      {/* Persistent Notification Center Dropdown */}
      {showNotifications && (
        <div className="fixed top-24 right-6 z-50 max-w-sm w-full bg-white text-charcoal rounded-xl border border-soft-warm-gray shadow-luxury-deep p-4 font-sans max-h-[480px] overflow-hidden flex flex-col animate-fade-in">
          <div className="flex justify-between items-center border-b border-soft-cream pb-2.5 mb-3">
            <span className="text-[10px] font-mono text-[#B5935B] font-bold uppercase tracking-widest flex items-center gap-1.5">
              <Bell className="w-4 h-4 text-[#B5935B] animate-bounce" /> AUREXIA VERIFIED ALERTS
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setNotifications([]);
                  setHasNewNotifications(false);
                }}
                className="text-[9px] font-mono text-gray-400 hover:text-charcoal font-bold tracking-wider cursor-pointer bg-transparent border-0"
              >
                CLEAR ALL
              </button>
              <button
                onClick={() => setShowNotifications(false)}
                className="text-gray-400 hover:text-charcoal font-bold text-xs p-1 cursor-pointer bg-transparent border-0"
              >
                ✕
              </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-400 text-xs italic">
                No system alerts or AI-detected events recorded in ledger.
              </div>
            ) : (
              notifications.map((notif) => (
                <div key={notif.id} className="p-3 bg-[#FAF8F5] rounded-lg border border-soft-warm-gray flex gap-2.5 items-start transition-colors hover:bg-gold/5 text-xs text-left">
                  <span className="w-1.5 h-1.5 rounded-full bg-gold shrink-0 mt-2"></span>
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] text-gray-700 leading-normal font-sans">{notif.text}</p>
                    <div className="flex items-center justify-between mt-1 text-[9px] font-mono text-gray-400">
                      <span>{notif.timestamp || "Just now"}</span>
                      <span className="text-gold font-bold text-[8px] uppercase">✓ Verified Ledger Log</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
          
          <div className="border-t border-soft-cream pt-3 mt-3 text-center">
            <span className="text-[9px] font-mono text-gray-400 uppercase block">
              AUREXIA TRUST OS INTEGRITY LOGS
            </span>
          </div>
        </div>
      )}

      {/* Fully Customized Premium Luxury Dark Slate Corporate Footer */}
      <footer className="mt-20 border-t border-[#B5935B]/25 bg-[#121B15] text-[#DCE2DD] pt-16 pb-8 px-6 text-xs font-sans">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          
          {/* Column 1: Website & Platform Identity */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded bg-[#EFE9E1] text-[#121B15] font-serif font-bold text-sm flex items-center justify-center border border-[#DACFC2] shadow-sm">
                A
              </span>
              <div>
                <h4 className="font-serif text-base tracking-widest font-bold text-[#E5D7BF]">AUREXIA</h4>
                <span className="text-[7.5px] font-mono tracking-wider text-[#B5935B] uppercase block">
                  Trust Systems OS Corp
                </span>
              </div>
            </div>
            
            <p className="text-[11px] text-gray-300 leading-relaxed font-sans">
              The premium, trust-driven operating system for creator marketing, automated escrow contracts, and human-ratio audience verification. Reconstructing brand influence on decentralized rails.
            </p>

            <div className="flex items-center gap-1.5 bg-[#1C2E21] text-emerald-300 text-[9px] font-mono font-semibold px-2.5 py-1 rounded border border-emerald-500/20 w-fit">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-450 animate-pulse"></span>
              <span>Ledger Node #109 Synced</span>
            </div>
          </div>

          {/* Column 2: System Directory (Quick navigation) */}
          <div className="space-y-3">
            <h5 className="font-serif text-xs font-bold text-[#E5D7BF] uppercase tracking-wider">Ecosystem Directory</h5>
            <ul className="space-y-2 font-mono text-[10.5px]">
              <li>
                <button onClick={() => setActiveScreen("landing")} className="hover:text-gold cursor-pointer flex items-center gap-1 transition-colors text-gray-300 bg-transparent border-0 p-0 text-left">
                  <span>↳</span> Homepage
                </button>
              </li>
              <li>
                <button onClick={() => { setActiveScreen("dashboard"); setDashboardTab("ai_network"); }} className="hover:text-gold cursor-pointer flex items-center gap-1 transition-colors text-gray-300 bg-transparent border-0 p-0 text-left">
                  <span>↳</span> AI Swarming Node
                </button>
              </li>
              <li>
                <button onClick={() => { setActiveScreen("dashboard"); setDashboardTab("trust_ledger"); }} className="hover:text-gold cursor-pointer flex items-center gap-1 transition-colors text-gray-300 bg-transparent border-0 p-0 text-left">
                  <span>↳</span> Trust Ledger Layer
                </button>
              </li>
              <li>
                <button onClick={() => { if(!currentUser) { setActiveScreen("login"); } else { setActiveScreen("dashboard"); setDashboardTab("campaign"); } }} className="hover:text-gold cursor-pointer flex items-center gap-1 transition-colors text-gray-300 bg-transparent border-0 p-0 text-left">
                  <span>↳</span> Campaign Escrows
                </button>
              </li>
              <li>
                <button onClick={() => { if(!currentUser) { setActiveScreen("login"); } else { setActiveScreen("dashboard"); setDashboardTab("analytics"); } }} className="hover:text-gold cursor-pointer flex items-center gap-1 transition-colors text-gray-300 bg-transparent border-0 p-0 text-left">
                  <span>↳</span> Yield & Analytics
                </button>
              </li>
              <li className="flex gap-2 text-[10px] text-gray-500 border-t border-white/10 pt-2 mt-2">
                <button onClick={() => { setActiveScreen("landing"); setTimeout(() => { document.getElementById("architecture-section")?.scrollIntoView({ behavior:"smooth" }); }, 100); }} className="hover:text-gold text-gray-400 bg-transparent border-0 p-0">Architecture</button>
                <span>•</span>
                <button onClick={() => { setActiveScreen("landing"); setTimeout(() => { document.getElementById("pricing-section")?.scrollIntoView({ behavior:"smooth" }); }, 100); }} className="hover:text-gold text-gray-400 bg-transparent border-0 p-0">Pricing</button>
                <span>•</span>
                <button onClick={() => { setActiveScreen("landing"); setTimeout(() => { document.getElementById("about-section")?.scrollIntoView({ behavior:"smooth" }); }, 100); }} className="hover:text-gold text-gray-400 bg-transparent border-0 p-0">About</button>
              </li>
            </ul>
          </div>

          {" "}
          {/* Column 3: Contact Channels */}
          <div className="space-y-3">
            <h5 className="font-serif text-xs font-bold text-[#E5D7BF] uppercase tracking-wider">Contact Channels</h5>
            <div className="space-y-2.5 text-[11px] font-sans">
              
              <div className="flex items-start gap-2">
                <Phone className="w-3.5 h-3.5 text-[#B5935B] shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <span className="text-[10px] text-gray-400 block font-mono">Global Hotlines</span>
                  <a href="tel:+18555438787" className="text-gray-200 font-semibold hover:underline block hover:text-gold transition-colors">+1 (855) 543-8787</a>
                  <a href="tel:+919110088220" className="text-gray-200 font-semibold hover:underline block hover:text-gold transition-colors">+91 91100 88220</a>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <Mail className="w-3.5 h-3.5 text-[#B5935B] shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <span className="text-[10px] text-gray-400 block font-mono">Operations Email</span>
                  <a href="mailto:trust@aurexia.com" className="text-gray-200 font-semibold hover:underline block hover:text-gold transition-colors">trust@aurexia.com</a>
                  <a href="mailto:ops@aurexia.io" className="text-gray-200 font-semibold hover:underline block hover:text-gold transition-colors">ops@aurexia.io</a>
                </div>
              </div>

              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#B5935B] shrink-0 mt-0.5" />
                <div className="space-y-0.5">
                  <span className="text-[10px] text-gray-400 block font-mono">Corporate Offices</span>
                  <span className="text-gray-300 leading-tight block">
                    Sovereign Block, level 14, Tower C, Bangalore, KA, India MB 560103.
                  </span>
                </div>
              </div>

            </div>
          </div>

          {/* Column 4: Social Nodes (Facebook, Insta, Twitter, TikTok) */}
          <div className="space-y-3">
            <h5 className="font-serif text-xs font-bold text-[#E5D7BF] uppercase tracking-wider">Social Nodes</h5>
            <p className="text-[10px] text-gray-400 font-sans">Follow our public system announcements and creative audits on verified profiles:</p>
            
            <div className="grid grid-cols-2 gap-2 pt-1 font-mono text-[10px]">
              
              <a href="https://facebook.com/aurexia.os" target="_blank" rel="noopener noreferrer" className="p-2 border border-white/10 rounded-lg bg-white/5 hover:bg-white/10 hover:border-[#B5935B] transition-all flex items-center gap-1.5 text-gray-300 hover:text-gold">
                <Facebook className="w-3.5 h-3.5 text-blue-400" />
                <span>Facebook</span>
              </a>

              <a href="https://instagram.com/aurexia.os" target="_blank" rel="noopener noreferrer" className="p-2 border border-white/10 rounded-lg bg-white/5 hover:bg-white/10 hover:border-[#B5935B] transition-all flex items-center gap-1.5 text-gray-300 hover:text-gold">
                <Instagram className="w-3.5 h-3.5 text-pink-400" />
                <span>Instagram</span>
              </a>

              <a href="https://twitter.com/aurexia_trust" target="_blank" rel="noopener noreferrer" className="p-2 border border-white/10 rounded-lg bg-white/5 hover:bg-white/10 hover:border-[#B5935B] transition-all flex items-center gap-1.5 text-gray-300 hover:text-gold">
                <Twitter className="w-3.5 h-3.5 text-sky-400" />
                <span>Twitter / X</span>
              </a>

              <a href="https://tiktok.com/@aurexia_os" target="_blank" rel="noopener noreferrer" className="p-2 border border-white/10 rounded-lg bg-white/5 hover:bg-white/10 hover:border-[#B5935B] transition-all flex items-center gap-1.5 text-gray-300 hover:text-gold">
                <span className="w-3.5 h-3.5 bg-black text-white flex items-center justify-center font-serif text-[8px] font-bold rounded-sm select-none">📱</span>
                <span>TikTok</span>
              </a>

            </div>

            <div className="pt-2 border-t border-white/10 text-[10px] font-sans text-gray-400">
              Disclaimer: All communications are encrypted end-to-end to secure sensitive briefing contracts.
            </div>
          </div>

        </div>

        {/* Bottom copyright & secure transaction metadata hashes */}
        <div className="border-t border-white/10 pt-8 flex flex-col md:flex-row justify-between items-center text-center md:text-left gap-4">
          <div className="space-y-1 text-gray-305">
            <p>&copy; 2026 AUREXIA OS Corp. (Aurexia OS Trust Systems Corp.). All Rights Reserved.</p>
            <p className="text-[10px] text-gray-400 font-sans">Standard operating guidelines and cryptographic parameters are property of AUREXIA OS.</p>
          </div>
          <div className="space-y-1 text-center md:text-right font-mono text-[10px]">
            <p className="text-[#B5935B] font-bold">SHA-256 Ledger: F8C339...1E8291EE</p>
            <p className="text-gray-450">Immutable secure compliance anchors valid • Gas optimizer yield: 0.002 gwei</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
