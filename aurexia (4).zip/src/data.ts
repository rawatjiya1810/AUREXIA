/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Creator,
  Brand,
  CampaignOpportunity,
  LinkedInPost,
  AIAgent,
  LiveActivity,
  CreatorCategory,
  Platform,
  CampaignCollaboration
} from "./types";

export const INITIAL_CREATORS: Creator[] = [
  {
    id: "creator_1",
    name: "Sarah Kapoor",
    handle: "@sarah.kapoor",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    banner: "https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&q=80&w=800",
    bio: "Sartorial storytelling and lifestyle architecture. Collaborating with premium sustainable brands globally.",
    category: CreatorCategory.FASHION,
    location: "Mumbai, MH",
    languages: ["English", "Hindi", "Punjabi"],
    platforms: [Platform.INSTAGRAM, Platform.YOUTUBE],
    followersCount: "1.4M",
    engagementRate: 8.7,
    predictedROI: 6.8,
    trustScore: {
      overall: 98,
      identityVerified: true,
      audienceAuthenticityScore: 97,
      campaignReliability: 99,
      brandFeedbackScore: 98,
      fraudRisk: "Low",
      blockchainTxHash: "0x8fa2...93b1"
    },
    achievements: ["VOGUE India 30 Under 30", "Aurexia Certified Partner", "Best Luxury Fashion Influencer 2025"],
    certifications: ["Decentralized Identity (DID) Cleared", "Audience Integrity Authenticated"],
    previousCollaborations: [
      { brand: "Nike', India", logo: "⚡", result: "2.4M reach, 8.7% engagement, 6.8x ROI" },
      { brand: "Zara Studio", logo: "✨", result: "1.8M impression, 9.2% engagement, 5.4x ROI" }
    ],
    audienceMetrics: {
      authenticPercentage: 97.4,
      topCountries: [
        { country: "India", percentage: 65 },
        { country: "United Kingdom", percentage: 15 },
        { country: "United States", percentage: 10 }
      ],
      ageGroups: [
        { group: "18-24", percentage: 25 },
        { group: "25-34", percentage: 55 },
        { group: "35-44", percentage: 20 }
      ]
    },
    reputationHistory: [
      { year: 2024, score: 91 },
      { year: 2025, score: 95 },
      { year: 2026, score: 98 }
    ],
    availabilityStatus: "Available",
    responseTime: "25 mins",
    verificationStatus: "Elite"
  },
  {
    id: "creator_2",
    name: "Marcus Chen",
    handle: "@marcus.tech.ai",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    banner: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800",
    bio: "Demystifying deep learning, smart hardware, and professional tech setups. High fidelity video production.",
    category: CreatorCategory.TECH,
    location: "San Francisco, CA",
    languages: ["English", "Mandarin"],
    platforms: [Platform.YOUTUBE, Platform.LINKEDIN],
    followersCount: "820K",
    engagementRate: 6.2,
    predictedROI: 8.2,
    trustScore: {
      overall: 96,
      identityVerified: true,
      audienceAuthenticityScore: 95,
      campaignReliability: 98,
      brandFeedbackScore: 94,
      fraudRisk: "Low",
      blockchainTxHash: "0x3e1a...2c5d"
    },
    achievements: ["Top Tech Creator on LinkedIn", "IEEE Creative Media Scholar 2025"],
    certifications: ["Identity Verified via Zero Knowledge DID", "Audience Bots Check Cleared"],
    previousCollaborations: [
      { brand: "Samsung Mobile", logo: "📱", result: "1.2M views, 7.5% link click interaction" },
      { brand: "Vercel Enterprise", logo: "▲", result: "45k high quality beta registration signups" }
    ],
    audienceMetrics: {
      authenticPercentage: 95.8,
      topCountries: [
        { country: "United States", percentage: 50 },
        { country: "Canada", percentage: 15 },
        { country: "United Kingdom", percentage: 12 }
      ],
      ageGroups: [
        { group: "18-24", percentage: 18 },
        { group: "25-34", percentage: 62 },
        { group: "35-44", percentage: 20 }
      ]
    },
    reputationHistory: [
      { year: 2024, score: 88 },
      { year: 2025, score: 92 },
      { year: 2026, score: 96 }
    ],
    availabilityStatus: "Busy",
    responseTime: "1 hour",
    verificationStatus: "Verified"
  },
  {
    id: "creator_3",
    name: "Chloe Dupont",
    handle: "@chloe_dupont",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
    banner: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&q=80&w=800",
    bio: "Parisian visual artist & luxury cosmetic editorial curator. Crafting elegant motion portraits.",
    category: CreatorCategory.BEAUTY,
    location: "Paris, FR",
    languages: ["English", "French"],
    platforms: [Platform.INSTAGRAM, Platform.TIKTOK],
    followersCount: "2.1M",
    engagementRate: 11.2,
    predictedROI: 7.4,
    trustScore: {
      overall: 95,
      identityVerified: true,
      audienceAuthenticityScore: 94,
      campaignReliability: 96,
      brandFeedbackScore: 95,
      fraudRisk: "Low",
      blockchainTxHash: "0x4ca1...8ef6"
    },
    achievements: ["Cannes Fashion Showcase Award 2025", "L'Oreal Global Brand Ambassador"],
    certifications: ["DID Multi-factor Proofed", "Aurexia Premium Partner Verified"],
    previousCollaborations: [
      { brand: "L'Oreal Luxe", logo: "💄", result: "12M impressions, +18% lift in brand affinity" },
      { brand: "Chanel Beauty", logo: "⚜", result: "800k video replays with high sentiment score" }
    ],
    audienceMetrics: {
      authenticPercentage: 94.2,
      topCountries: [
        { country: "France", percentage: 40 },
        { country: "United States", percentage: 25 },
        { country: "Japan", percentage: 15 }
      ],
      ageGroups: [
        { group: "18-24", percentage: 45 },
        { group: "25-34", percentage: 40 },
        { group: "35-44", percentage: 15 }
      ]
    },
    reputationHistory: [
      { year: 2024, score: 92 },
      { year: 2025, score: 94 },
      { year: 2026, score: 95 }
    ],
    availabilityStatus: "Available",
    responseTime: "4 hours",
    verificationStatus: "Elite"
  },
  {
    id: "creator_4",
    name: "Rajesh Sharma",
    handle: "@rajesh_wellness",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200",
    banner: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?auto=format&fit=crop&q=80&w=800",
    bio: "Holistic health advocate, organic diet coaching, and mindful movement tutorials. Connecting wellness brands to genuine communities.",
    category: CreatorCategory.FITNESS,
    location: "Gurugram, HR",
    languages: ["English", "Hindi", "Marathi"],
    platforms: [Platform.YOUTUBE, Platform.INSTAGRAM],
    followersCount: "680K",
    engagementRate: 5.8,
    predictedROI: 9.1,
    trustScore: {
      overall: 99,
      identityVerified: true,
      audienceAuthenticityScore: 99,
      campaignReliability: 100,
      brandFeedbackScore: 99,
      fraudRisk: "Low",
      blockchainTxHash: "0x7bb3...5a2a"
    },
    achievements: ["Wellness Innovator of the Year", "AYUSH Ministry Digital Partner"],
    certifications: ["Zero Bot Verification Certified", "Reputation Smart-Contract Validated"],
    previousCollaborations: [
      { brand: "Premium Foods", logo: "🍃", result: "5k product subscriptions, 9.1x ROI" },
      { brand: "YogaBar India", logo: "🍫", result: "25k coupon redemptions with 15% conversion rate" }
    ],
    audienceMetrics: {
      authenticPercentage: 99.1,
      topCountries: [
        { country: "India", percentage: 85 },
        { country: "United Arab Emirates", percentage: 8 },
        { country: "Singapore", percentage: 4 }
      ],
      ageGroups: [
        { group: "18-24", percentage: 15 },
        { group: "25-34", percentage: 50 },
        { group: "35-44", percentage: 35 }
      ]
    },
    reputationHistory: [
      { year: 2024, score: 96 },
      { year: 2025, score: 98 },
      { year: 2026, score: 99 }
    ],
    availabilityStatus: "Available",
    responseTime: "10 mins",
    verificationStatus: "Elite"
  }
];

export const INITIAL_BRANDS: Brand[] = [
  {
    id: "brand_1",
    name: "Nike India",
    logo: "⚡",
    industry: "Athletic & Lifestyle Apparel",
    reliabilityScore: 98,
    campaignBudgetRange: "₹10,00,000 - ₹50,00,000",
    successfulCampaigns: 42,
    location: "Bengaluru, KA",
    feedbackScore: 96
  },
  {
    id: "brand_2",
    name: "Samsung Global",
    logo: "📱",
    industry: "Consumer Electronics & AI Tech",
    reliabilityScore: 95,
    campaignBudgetRange: "$50,000 - $250,000",
    successfulCampaigns: 118,
    location: "Seoul / San Jose",
    feedbackScore: 94
  },
  {
    id: "brand_3",
    name: "Zara Studio",
    logo: "✨",
    industry: "Premium & High Street Fashion",
    reliabilityScore: 92,
    campaignBudgetRange: "₹5,00,000 - ₹20,00,000",
    successfulCampaigns: 29,
    location: "Mumbai / A Coruña",
    feedbackScore: 90
  }
];

export const INITIAL_CAMPAIGNS: CampaignOpportunity[] = [
  {
    id: "camp_1",
    brandId: "brand_1",
    brandName: "Nike India",
    brandLogo: "⚡",
    brandReliabilityScore: 98,
    title: "Air Max Infinity Launch",
    description: "Launch campaign highlighting the recycled elements and unparalleled comfort of the Air Max Infinity. Focus on organic everyday wear integration rather than hard-sell fitness reviews.",
    budget: 2000000, // INR 20 Lakhs
    lookingFor: "Fitness / Wellness & High Fashion Creators",
    platform: Platform.INSTAGRAM,
    deadline: "2026-07-20",
    audienceMatchPercent: 96,
    predictedReach: "2.5M - 4M impressions",
    predictedEngagement: "8.5%",
    predictedConversions: "12,500 units",
    predictedROI: 6.8,
    status: "Open",
    deliverablesList: ["1 Instagram Carousel", "2 Reels with Brand Tag", "1 Story Series with link sticker"]
  },
  {
    id: "camp_2",
    brandId: "brand_2",
    brandName: "Samsung Global",
    brandLogo: "📱",
    brandReliabilityScore: 95,
    title: "Galaxy AI: Next-Gen Creative Toolkit",
    description: "Create cinematic, practical content highlighting Galaxy AI editing capabilities like Object Re-composer, real-time live transcribing, and sketch-to-image workflows.",
    budget: 8000000, // INR 80 Lakhs (approx $100k USD)
    lookingFor: "Technology, Creator Production, AI Scholars",
    platform: Platform.YOUTUBE,
    deadline: "2026-08-15",
    audienceMatchPercent: 94,
    predictedReach: "5M+ views",
    predictedEngagement: "5.8%",
    predictedConversions: "4,200 device purchases",
    predictedROI: 8.2,
    status: "Open",
    deliverablesList: ["1 Dedicated YouTube Video (10+ mins)", "2 YouTube Shorts integration", "1 LinkedIn Professional Case Study"]
  },
  {
    id: "camp_3",
    brandId: "brand_3",
    brandName: "Zara Studio",
    brandLogo: "✨",
    brandReliabilityScore: 92,
    title: "Autumn Capsule Editorial",
    description: "Curated styling guide based on Zara Autumn luxury knitwear. Elegant mood frames, cinematic styling, muted earth tones matching visual palettes.",
    budget: 800000, // INR 8 Lakhs
    lookingFor: "Premium High Contrast Luxury Stylists",
    platform: Platform.INSTAGRAM,
    deadline: "2026-09-01",
    audienceMatchPercent: 91,
    predictedReach: "1.2M impressions",
    predictedEngagement: "9.2%",
    predictedConversions: "1,800 jacket orders",
    predictedROI: 5.4,
    status: "Open",
    deliverablesList: ["1 Aesthetic Reel (15s)", "1 Instagram Carousel with editorial outfit codes"]
  }
];

export const INITIAL_POSTS: LinkedInPost[] = [
  {
    id: "post_1",
    creatorId: "creator_1",
    creatorName: "Sarah Kapoor",
    creatorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    creatorHandle: "@sarah.kapoor",
    category: "Campaign Milestones",
    timestamp: "2 hours ago",
    content: "Thrilled to share the final performance metrics for the Nike Air Max launch collaboration! Using local sustainable styling stories, we created cinematic reels that drove incredible organic response. Visual authenticity remains the highest converting metric in modern commerce. ⚡👟",
    metrics: {
      reach: "2.4M reach",
      engagement: "8.7% engagement",
      trustScore: "96 → 98",
      roi: "6.8x ROI"
    },
    imageUrl: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&q=80&w=800",
    likes: 142,
    hasLiked: false
  },
  {
    id: "post_2",
    creatorId: "creator_2",
    creatorName: "Marcus Chen",
    creatorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    creatorHandle: "@marcus.tech.ai",
    category: "AI & Creator Economics",
    timestamp: "1 day ago",
    content: "Why are brands wasting millions on unverified, botted follower counts? We ran a audit of my audience across YouTube and LinkedIn using Aurexia's Decentralized Identity (DID) system. Real outcome checks show 95.8% audience authenticity score. Trust leads directly to 8.2x predicted conversion yield. Brands: demand cryptographic verification, stop guessing. 🦾📊",
    metrics: {
      reach: "850K impressions",
      engagement: "11.4% clicks",
      trustScore: "96 Verified",
      roi: "8.2x ROI"
    },
    imageUrl: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=800",
    likes: 319,
    hasLiked: true
  }
];

export const INITIAL_AGENTS: AIAgent[] = [
  {
    id: "agent_1",
    name: "Creator Discovery Agent",
    role: "Semantic Matching & Category Filter Engine",
    avatar: "🧠",
    status: "active",
    lastAction: "Discovered 14 premium creators matching the Nike Recycled Footwear brief.",
    description: "Evaluates visual content semantic tags and creators' text history to match true style to brand sentiment without relying on generic hashtags."
  },
  {
    id: "agent_2",
    name: "Audience Analyst Agent",
    role: "Cryptographic Authenticity Audit Log",
    avatar: "🛡️",
    status: "idle",
    lastAction: "Audited @sarah.kapoor and issued ZK-Proof verification for 97.4% human authenticity.",
    description: "Scans follower activity patterns, commenting timings, and geo-data to detect bot swarms, abnormal growth spikes, and fake engagement spikes."
  },
  {
    id: "agent_3",
    name: "Campaign Strategist Agent",
    role: "ROI Forecasting & Deliverable Structuring",
    avatar: "📈",
    status: "active",
    lastAction: "Calculated budget optimization for Samsung Galaxy launch: suggested shifting 15% budget to short-form tech.",
    description: "Simulates historical performance yields to generate optimal pricing, deliverables, and predicted campaign ROI metrics."
  },
  {
    id: "agent_4",
    name: "Trust Monitor Agent",
    role: "On-Chain Verification & Reputation Tracking",
    avatar: "⛓️",
    status: "processing",
    lastAction: "Anchored Sarah Kapoor's campaign completion record onto Polygon Trust Ledger (Tx: 0x8fa2...93b1).",
    description: "Maintains immutable, dual-party cryptographically signed records of payments, timeliness, contract adherence, and feedback scores."
  },
  {
    id: "agent_5",
    name: "Performance Optimizer Agent",
    role: "Federated Trend Adaptor",
    avatar: "⚡",
    status: "idle",
    lastAction: "Calculated that knits and editorial style hooks have experienced a 24% engagement increase in the luxury sector.",
    description: "Identifies rising engagement vectors across regions and formats without storing private localized user data."
  }
];

export const INITIAL_ACTIVITIES: LiveActivity[] = [
  {
    id: "act_1",
    text: "🧠 AI Discovery Agent matched Sarah Kapoor with Nike Air Max Launch (96% overlap score).",
    type: "ai_match",
    timestamp: "Just now"
  },
  {
    id: "act_2",
    text: "⛓️ Trust Score for Marcus Chen has been updated on-chain to 96 after Samsung contract closure.",
    type: "trust_update",
    timestamp: "3 mins ago"
  },
  {
    id: "act_3",
    text: "📈 Campaign ROI Forecast for Galaxy AI Creative toolkit predicted at 8.2x.",
    type: "roi_forecast",
    timestamp: "12 mins ago"
  },
  {
    id: "act_4",
    text: "🛡️ Audience verification issued ZK-Proof authenticity score of 99.1% for Rajesh Sharma.",
    type: "audience_match",
    timestamp: "1 hour ago"
  },
  {
    id: "act_5",
    text: "🤝 New campaign opportunity 'Autumn Capsule' posted by Zara Studio (Budget: ₹8,00,000).",
    type: "opportunity",
    timestamp: "2 hours ago"
  }
];

export const INITIAL_COLLABORATIONS: CampaignCollaboration[] = [
  {
    id: "collab_1",
    campaignId: "camp_1",
    campaignTitle: "Air Max Infinity Launch",
    brandName: "Nike India",
    brandLogo: "⚡",
    creatorName: "Sarah Kapoor",
    creatorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    budget: 2000000,
    status: "Deliverables Tracked",
    smartContractAddress: "0x78Ce...Fb8d10C2937",
    deliverables: [
      { id: "del_1", title: "Instagram Carousel: Sustainable Lookbook", status: "Approved", dueDate: "2026-07-01", notes: "Approved by Nike Brand Manager with high feedback." },
      { id: "del_2", title: "Aesthetic Reel: Day in motion with Air Max", status: "Review Stage", dueDate: "2026-07-10", notes: "Draft uploaded. Under AI brand guidelines audit." },
      { id: "del_3", title: "Instagram Stories: Direct Link Integration", status: "Assigned", dueDate: "2026-07-15", notes: "Awaiting approval of Reel before story trigger." }
    ],
    logs: [
      { time: "2026-06-10 10:00", event: "Smart Contract deployed to Polygon with dual-signatures." },
      { time: "2026-06-12 14:30", event: "Creator Sarah Kapoor submitted Carousel Draft with asset links." },
      { time: "2026-06-13 09:12", event: "Nike approved Carousel Draft. Escrow partial release of ₹5,00,000 pending." },
      { time: "2026-06-15 11:00", event: "Creator submitted Aesthetic Reel draft video proof." }
    ]
  }
];
