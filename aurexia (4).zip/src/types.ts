/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum CreatorCategory {
  FASHION = "Fashion & Luxury",
  LIFESTYLE = "Lifestyle",
  TECH = "Technology & AI",
  FITNESS = "Fitness & Wellness",
  BEAUTY = "Beauty & Cosmetics",
  TRAVEL = "Travel & Culinary"
}

export enum Platform {
  INSTAGRAM = "Instagram",
  YOUTUBE = "YouTube",
  TIKTOK = "TikTok",
  LINKEDIN = "LinkedIn"
}

export interface TrustScoreBreakdown {
  overall: number; // 0 to 100
  identityVerified: boolean;
  audienceAuthenticityScore: number; // 0-100
  campaignReliability: number; // 0-100
  brandFeedbackScore: number; // 0-100
  fraudRisk: "Low" | "Medium" | "High";
  blockchainTxHash?: string;
}

export interface Creator {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  banner: string;
  bio: string;
  category: CreatorCategory;
  location: string;
  languages: string[];
  platforms: Platform[];
  followersCount: string;
  engagementRate: number; // percentage
  predictedROI: number; // multiplier e.g. 8.2
  trustScore: TrustScoreBreakdown;
  achievements: string[];
  certifications: string[];
  previousCollaborations: { brand: string; logo: string; result: string }[];
  audienceMetrics: {
    authenticPercentage: number;
    topCountries: { country: string; percentage: number }[];
    ageGroups: { group: string; percentage: number }[];
  };
  reputationHistory: { year: number; score: number }[];
  availabilityStatus: "Available" | "Busy" | "Fully Booked";
  responseTime: string; // e.g. "2 hours"
  verificationStatus: "Verified" | "Elite" | "Pending";
}

export interface Brand {
  id: string;
  name: string;
  logo: string;
  industry: string;
  reliabilityScore: number; // 0 to 100
  campaignBudgetRange: string;
  successfulCampaigns: number;
  location: string;
  feedbackScore: number;
}

export interface CampaignOpportunity {
  id: string;
  brandId: string;
  brandName: string;
  brandLogo: string;
  brandReliabilityScore: number;
  title: string;
  description: string;
  budget: number; // in standard currency units (e.g. INR or USD)
  lookingFor: string;
  platform: Platform;
  deadline: string;
  audienceMatchPercent: number;
  predictedReach: string;
  predictedEngagement: string;
  predictedConversions: string;
  predictedROI: number;
  status: "Open" | "In Review" | "Active" | "Completed";
  deliverablesList: string[];
}

export interface LinkedInPost {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  creatorHandle: string;
  category: string;
  timestamp: string;
  content: string;
  metrics: {
    reach: string;
    engagement: string;
    trustScore: string;
    roi: string;
  };
  imageUrl?: string;
  likes: number;
  hasLiked?: boolean;
}

export interface Message {
  id: string;
  senderId: string; // brand or creator
  senderName: string;
  senderType: "brand" | "creator" | "system";
  text: {
    original: string;
    translated?: string;
    language?: string;
  };
  timestamp: string;
  attachment?: {
    type: "image" | "contract" | "deliverable";
    name: string;
    url?: string;
    status?: string;
  };
}

export interface AIAgent {
  id: string;
  name: string;
  role: string;
  avatar: string;
  status: "active" | "idle" | "processing";
  lastAction: string;
  description: string;
}

export interface LiveActivity {
  id: string;
  text: string;
  type: "ai_match" | "trust_update" | "roi_forecast" | "audience_match" | "request" | "opportunity";
  timestamp: string;
}

export interface DeliverableTracker {
  id: string;
  title: string;
  status: "Assigned" | "Draft Submitted" | "Review Stage" | "Approved" | "Payment Released";
  dueDate: string;
  notes?: string;
}

export interface CampaignCollaboration {
  id: string;
  campaignId: string;
  campaignTitle: string;
  brandName: string;
  brandLogo: string;
  creatorName: string;
  creatorAvatar: string;
  budget: number;
  status: "Contract Generated" | "Deliverables Tracked" | "Milestones Verified" | "Payment Released";
  smartContractAddress: string;
  deliverables: DeliverableTracker[];
  logs: { time: string; event: string }[];
}
